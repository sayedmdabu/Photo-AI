<a style="background-color:blueviolet; color:aliceblue" {{ $attributes->merge(['class' => 'inline-flex items-center btn btn-info ...']) }}>
    {{ $slot }}
</a>