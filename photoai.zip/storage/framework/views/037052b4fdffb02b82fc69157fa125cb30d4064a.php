<a style="background-color:blueviolet; color:aliceblue" <?php echo e($attributes->merge(['class' => 'inline-flex items-center btn btn-info ...'])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH /home/sayed/Documents/photoai/resources/views/components/link.blade.php ENDPATH**/ ?>