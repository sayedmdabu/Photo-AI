import os, base64
from flask import Flask,  request
from datetime import datetime
from shutil import copyfile


PROJECT_ROOT = os.path.dirname(os.path.realpath(__file__))
COMMON_INSTANCE_NAME = "slnisd"
SAVING_DIR= os.path.join(PROJECT_ROOT, f"{COMMON_INSTANCE_NAME}")

app = Flask(__name__)


@app.route("/req", methods=["POST"])
def req():
    content = request.json
    image_ls = content['image_ls']
    image_format = content["image_format"]
    
    os.system(f"rm -rf {SAVING_DIR}/*")
    
    
    
    cnt =1
    for image_data in image_ls:
        if image_data:
            image_data = image_data.encode('utf-8')
            image = base64.b64decode(image_data)
            with open(os.path.join(f'{SAVING_DIR}', f'{COMMON_INSTANCE_NAME} ({cnt}).{image_format}'), 'wb') as f:
                f.write(image)
            cnt += 1
            
    return 'done', 200


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=8693, debug=True)
