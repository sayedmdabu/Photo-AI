import os
import glob
from fpdf import FPDF
from pathlib import Path


def show_all_images(input_folder,  height, width, font_size=8, print_text=True,
                    pdf_page_strt_x=0, pdf_page_strt_y=0, row_to_row_height=3,
                    col_to_col_width=3, pdf_page_height=245, pdf_page_width=100,
                    numerically_sort=False, report_name='table.pdf', captions=["photo of slnisd man", "photo of st001 man",
                                                                               "photo of st001 man with face of slnisd man",
                                                                               "photo of slnisd man with face of st001 man",
                                                                               "photo of slnisd man with face of st001  man dress like st001 man pose like st001 man",
                                                                               ]
                    ):
    # Create a PDF object
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font('Arial', "B", font_size)
    # Set the initial y coordinate
    x = pdf_page_strt_x  # starting x position
    y = pdf_page_strt_y  # starting y position
    if numerically_sort:
        def key(x): return int(os.path.splitext(x)[0])
    else:
        key = None
    # Iterate through the input folder
    image_x_position = x
    for idx, input_image in enumerate(sorted(os.listdir(input_folder), key=key)):

        # Add the input image
        if image_x_position+width > pdf_page_width:
            x = pdf_page_strt_x
            y += height + row_to_row_height + 10
            image_x_position = x

        if y+height+row_to_row_height >= pdf_page_height:
            pdf.add_page()
            y = pdf_page_strt_y
            x = pdf_page_strt_x

        # print(f"{input_image}, {image_x_position},{y}")

        pdf.image(f'{input_folder}/{input_image}',
                  x=image_x_position, y=y, w=height, h=width)

        # if print_text:
        #     pdf.text(txt=captions[idx], x=image_x_position,
        #              y=y+height+row_to_row_height)

        if print_text:
            # wrap the text if it goes beyond the width of the page
            pdf.set_xy(image_x_position, y+height+row_to_row_height)
            pdf.multi_cell(width, font_size, captions[idx], 0, 'L')

        image_x_position += width + col_to_col_width

        # Add New Page if filled all page space

    # Save the PDF
    pdf.output(report_name)


if __name__ == '__main__':
    input_folder = f"output"
    show_all_images(input_folder=input_folder, pdf_page_strt_x=3, pdf_page_strt_y=20, print_text=True,
                    row_to_row_height=3, col_to_col_width=3, pdf_page_height=245, pdf_page_width=150,
                    font_size=8, height=100, width=100,
                    numerically_sort=True, report_name="table.pdf",
                    captions=["one", "two", "3","4"])
    
