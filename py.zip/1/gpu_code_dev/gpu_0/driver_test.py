import os
import ast
import argparse
import random
import json
import time
import requests

################################################################
max_train_steps = 1500
GPU_NO = int(os.path.basename(os.getcwd()).replace("gpu_", ""))
MODEL_OUTPUT_ROOT_DIR = f"./stable_diffusion_weights"
pdf_report_root_dir = f"./pdf_report"
image_output_dir = f"./output"
all_results_dir = f'./content/data/results'
################################################################


def ping_test():
    return requests.request("GET", url="http://localhost:8000/ping", headers={}, data={})


if __name__ == "__main__":  # e.g: python3 driver_test.py --train "False" --infer "True"

    all_requests_folder_path = f"./content/data/requests"

    print(f"hello from {os.path.basename(__file__)}")

    while (True):
        try:

            # print(ping_test().text)

            subfolder_list = [f.path for f in os.scandir(
                all_requests_folder_path) if f.is_dir()]

            if not subfolder_list:
                time.sleep(3)
                # print("On Sleep")
                continue

            selected_request_folder = random.choice(subfolder_list)
            with open(f"{selected_request_folder}/request.json", "r") as file:
                content = json.load(file)

            order_id, gpu_id = content['order_id'], content['gpu_id']
            style_ls = content['style_ls']
            train = content['train']
            infer = content["infer"]
            image_format = content["image_format"]
            generation_status = content["generation_status"]

            instance_name = os.path.basename(selected_request_folder)

            for style_name in style_ls:

                CURRENT_MODEL_SAVE_DIR = f"{MODEL_OUTPUT_ROOT_DIR}/{instance_name}/{style_name}/{max_train_steps}"
                STYLE_RESULTS_SAVING_DIR = f"{all_results_dir}/{instance_name}/{style_name}"

                if train == "True":
                    print(
                        f" Training: Style: {style_name} Instance: {instance_name}")
                    os.system(
                        f"CUDA_VISIBLE_DEVICES={GPU_NO} python3 train.py  --remove_prev_models 'True' --max_train_steps {max_train_steps} --style_name {style_name} --instance_name {instance_name} ")
                    # time.sleep(15)

                if infer == "True":
                    print(
                        f" Inferring: Style: {style_name} Instance: {instance_name}")
                    os.system(
                        f"CUDA_VISIBLE_DEVICES={GPU_NO} python3 infer.py --image_output_dir {image_output_dir} --max_train_steps {max_train_steps} --remove_output_imgs 'True' --style_name {style_name} --instance_name {instance_name}  ")
                    os.system(
                        f"mkdir -p {STYLE_RESULTS_SAVING_DIR}")
                    os.system(
                        f"cp -r {image_output_dir}/* {STYLE_RESULTS_SAVING_DIR}")

                    #clean up request
                    os.system(f"rm -rf {selected_request_folder}")
                    os.system(f"rm -rf output/*")
                    # time.sleep(15)

        except Exception as e:
            break
