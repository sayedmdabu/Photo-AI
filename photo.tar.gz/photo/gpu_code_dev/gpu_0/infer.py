# -*- coding: utf-8 -*-
import os
import argparse
from pdf_gen import show_all_images


def rename_images(dir_path):
    i = 1
    for filename in os.listdir(dir_path):
        # get file extension
        file_extension = os.path.splitext(filename)[1]
        # rename the file
        os.rename(os.path.join(dir_path, filename), os.path.join(dir_path, str(i) + file_extension))
        i += 1

        
if __name__ == "__main__":  # e.g: python3 infer.py --style_name st002 --instance_name dt578341465
    parser = argparse.ArgumentParser()
    parser.add_argument('--style_name', type=str,
                        default=None, help='Name of the style')
    parser.add_argument('--instance_name', type=str,
                        default=None, help='Name of the instance')
    parser.add_argument('--remove_output_imgs', type=str,
                        default="False", help='Remove output images.')
    parser.add_argument('--width', type=int,
                        default=512, help='Remove output images.')
    parser.add_argument('--height', type=int,
                        default=512, help='Remove output images.')
    parser.add_argument('--max_train_steps', type=int,
                        default=1500, help='Remove output images.')
    parser.add_argument('--num_samples', type=int,
                        default=1, help='Remove output images.')
    parser.add_argument('--guidance_scale', type=int,
                        default=9, help='Remove output images.')
    parser.add_argument('--num_inference_steps', type=int,
                        default=50, help='Remove output images.')
    parser.add_argument('--image_output_dir', type=str,
                        default=f"./output", help='DIR for output images.')

    args = parser.parse_args()

    ## command line params
    style_name = args.style_name
    instance_name = args.instance_name
    remove_output_imgs = args.remove_output_imgs
    height = args.height
    width = args.width
    max_train_steps = args.max_train_steps
    num_inference_steps = args.num_inference_steps
    guidance_scale = args.guidance_scale
    num_samples = args.num_samples
    image_output_dir = args.image_output_dir

    ############3

    negative_prompt_ls = []
    prompt_ls = []
    with open(f"./prompts/{style_name}.txt", "r") as f:
        lines = f.readlines()
        for idx, line in enumerate(lines, start=1):
            if idx % 2 == 0:
                negative_prompt_ls.append(line.strip())
            else:
                prompt_ls.append(line.strip())

    ### other params #################################
    common_instance_name = "slnisd"
    ALL_WEIGHTS_DIR = f"./stable_diffusion_weights"
    OUTPUT_DIR = f"./stable_diffusion_weights/{instance_name}"
    WEIGHTS_DIR = f"{ALL_WEIGHTS_DIR}/{instance_name}/{style_name}/{max_train_steps}"
    # pdf report related
    pdf_report_dir = f"./pdf_report/{instance_name}"
    pdf_report_name = f"{pdf_report_dir}/{style_name}_{instance_name}.pdf"
    MODEL_NAME = "runwayml/stable-diffusion-v1-5"

    os.system(f"mkdir -p {pdf_report_dir}")

    # if remove_output_imgs == "True":
    #     os.system(f"rm -rf {image_output_dir}/*")


    rename_images(dir_path='output')
    show_all_images(input_folder="output", pdf_page_strt_x=1, pdf_page_strt_y=1,
                    row_to_row_height=3, col_to_col_width=3,  pdf_page_height=290, pdf_page_width=280,
                    font_size=8, height=70, width=70,
                    numerically_sort=True, report_name=pdf_report_name,  print_text=False, captions=prompt_ls)
