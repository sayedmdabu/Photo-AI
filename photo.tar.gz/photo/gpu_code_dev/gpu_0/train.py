# -*- coding: utf-8 -*-
import json
import os
import argparse

if __name__ == "__main__":  # e.g: python3 train.py --style_name st002 --instance_name dt578341465
    parser = argparse.ArgumentParser()
    parser.add_argument('--style_name', type=str,
                        default=None, help='Name of the style')
    parser.add_argument('--instance_name', type=str,
                        default=None, help='Name of the instance')
    parser.add_argument('--remove_prev_models', type=str,
                        default="False", help='if remove_prev_models')
    parser.add_argument('--max_train_steps', type=int,
                        default=1500, help='Give max_train_steps')

    args = parser.parse_args()
    ## command line params
    style_name = args.style_name
    instance_name = args.instance_name
    remove_prev_models = args.remove_prev_models
    max_train_steps = args.max_train_steps

    os.system(f"rm -rf content/data/slnisd/*")
    os.system(
        f"cp -r content/data/Datasets/{instance_name}/* content/data/slnisd")
    os.system(f"rm -rf content/data/st001/*")
    os.system(f"cp -r content/data/Template/{style_name}/* content/data/st001")

    OUTPUT_DIR = f"./stable_diffusion_weights/{instance_name}/{style_name}"
    if remove_prev_models == "True":
        os.system(f"rm -rf {OUTPUT_DIR}/*")

    
    os.system(
        f"cp -r content/data/Datasets/{instance_name}/* output/")
