import os

# os.system(f"sudo chmod -R 777 *")

# app_port=8000

# try:
#     os.system(f'sudo kill -9 $(sudo lsof -t -i:{app_port})')
# except Exception as e:
#     pass

# start app server
os.system(f"nohup python3 app.py & ")

# start gpu services
os.chdir(f"gpu_0")
os.system(f"python3 driver_test.py")
# os.chdir(f"../")
