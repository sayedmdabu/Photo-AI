# AWS Related 
1. AMI ID: ami-00874d747dde814fa
AMI name: ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-20230115
2. Instance type
g4dn.xlarge
3. Virtualization type: hvm
Number of vCPUs: 4


# CUDA Setup: https://developer.nvidia.com/cuda-11-7-0-download-archive?target_os=Linux&target_arch=x86_64&Distribution=Ubuntu&target_version=22.04&target_type=runfile_local

```
wget https://developer.download.nvidia.com/compute/cuda/11.7.0/local_installers/cuda_11.7.0_515.43.04_linux.run
sudo sh cuda_11.7.0_515.43.04_linux.run
```

## install deps
1. sudo apt-get update ; sudo apt install nano ; sudo apt install screen ; sudo apt-get -y install python3-pip ; sudo apt install python3-venv ; python3 -m venv v3 ;
2. **manually**:      source  v3/bin/activate
3. pip install -r requirements.txt

## Check : Add in ~/.bashrc
1. LD_LIBRARY_PATH check:
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
output:
```
echo "$LD_LIBRARY_PATH"
/usr/local/cuda/lib64:/usr/lib/x86_64-linux-gnu:
```

1. PATH check:
echo "$PATH"
/home/ubuntu/gpu_code/v3/bin:/home/ubuntu/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/usr/local/cuda/bin


# Record:

(v3) ubuntu@ip-172-31-84-140:~/gpu_code$ nvcc --version ;  nvidia-smi ;
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2022 NVIDIA Corporation
Built on Tue_May__3_18:49:52_PDT_2022
Cuda compilation tools, release 11.7, V11.7.64
Build cuda_11.7.r11.7/compiler.31294372_0
Sun Feb  5 03:58:17 2023       
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 515.43.04    Driver Version: 515.43.04    CUDA Version: 11.7     |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|                               |                      |               MIG M. |
|===============================+======================+======================|
|   0  Tesla T4            Off  | 00000000:00:1E.0 Off |                    0 |
| N/A   40C    P0    26W /  70W |      2MiB / 15360MiB |      4%      Default |
|                               |                      |                  N/A |
+-------------------------------+----------------------+----------------------+
                                                                               
+-----------------------------------------------------------------------------+
| Processes:                                                                  |
|  GPU   GI   CI        PID   Type   Process name                  GPU Memory |
|        ID   ID                                                   Usage      |
|=============================================================================|
|  No running processes found                                                 |
+-----------------------------------------------------------------------------+
