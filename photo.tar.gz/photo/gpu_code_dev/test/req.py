import requests
import os
import glob
import base64
import json


url = "http://localhost:8000/req"
images_dir = "Datasets/slnisd"

files = glob.glob(f"{images_dir}/*")

ls_encoded_string = []
for file in files:
    with open(file, "rb") as image_file1:
        ls_encoded_string.append(base64.b64encode(
            image_file1.read()).decode("utf-8"))

# print (len(ls_encoded_string))

data = {
    "order_id": 124,
    "gpu_id": 0,
    "style_ls": ["st001", "st002"],
    "train": "True",
    "infer": "True",
    "image_format": "jpg",
    "image_ls": ls_encoded_string

}


with open("data.json", "w") as file:
    json.dump(data, file)


response = requests.post(url, json=data)
print(response)
