req:

curl --location --request POST 'http://localhost:4000/reqform' \
--header 'Content-Type: application/json' \
--form 'order_id="326"' \
--form 'gpu_id="0"' \
--form 'style_ls="st001,st002"' \
--form 'train="True"' \
--form 'infer="True"' \
--form 'image_format="jpg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (15).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (14).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (13).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (12).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (11).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (10).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (9).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (8).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (7).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (6).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (5).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (4).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (3).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (2).jpeg"' \
--form 'image_ls=@"/home/yasin/Downloads/sd/slnisd/slnisd (1).jpeg"'





res:
curl --location --request GET 'http://localhost:4000/res' \
--header 'Content-Type: application/json' \
--data-raw '{
    "order_id": 326,
    "gpu_id": 0,
    "style_name": "st002"
}'