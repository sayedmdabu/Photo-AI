import os
import json
import shutil
import base64
from flask import Flask,  request
from datetime import datetime
from shutil import copyfile
from flask import Flask, jsonify, request, send_from_directory
import json
import os
import signal


PROJECT_ROOT = os.path.dirname(os.path.realpath(__file__))
COMMON_INSTANCE_NAME = "slnisd"


app = Flask(__name__)
app_port = 8000


def save_files(image_ls, image_format, SAVING_DIR):
    cnt = 1
    for image_data in image_ls:
        if image_data:
            image_data = image_data.encode('utf-8')
            image = base64.b64decode(image_data)
            with open(os.path.join(f'{SAVING_DIR}', f'{COMMON_INSTANCE_NAME} ({cnt}).{image_format}'), 'wb') as f:
                f.write(image)
            cnt += 1

#############################################


@app.route("/ping", methods=["GET"])
def pong():
    return "OK", 200


@app.route('/shutdown', methods=['GET'])
def stopServer():
    try:
        os.system(f'sudo kill -9 $(sudo lsof -t -i:{app_port})')
    except Exception as e:
        pass

    os.kill(os.getpid(), signal.SIGINT)
    return jsonify({"success": True, "message": "Server is shutting down..."})


@app.route("/reqform", methods=["POST"])
def save_req_form_data():

    order_id, gpu_id = request.form.get(
        'order_id').strip(), request.form.get('gpu_id').strip()
    style_ls = [x.strip()
                for x in request.form.getlist('style_ls')[0].split(',')]
    train = request.form.get('train').strip()
    infer = request.form.get("infer").strip()
    image_ls = request.files.getlist("image_ls")
    image_format = request.form.get("image_format").strip()

    ls_encoded_string = []
    for file in image_ls:
        ls_encoded_string.append(base64.b64encode(
            file.read()).decode("utf-8"))

    image_ls = ls_encoded_string

    SAVING_DIR = f"./gpu_{str(gpu_id)}/content/data/Datasets/{str(order_id)}"

    REQUESTS_SAVING_DIR = f"./gpu_{str(gpu_id)}/content/data/requests/{str(order_id)}"
    print(SAVING_DIR)
    if os.path.exists(SAVING_DIR):
        shutil.rmtree(SAVING_DIR)
    os.makedirs(SAVING_DIR)

    if os.path.exists(REQUESTS_SAVING_DIR):
        shutil.rmtree(REQUESTS_SAVING_DIR)
    os.makedirs(REQUESTS_SAVING_DIR)

    save_content = {
        "order_id": order_id,
        "gpu_id": gpu_id,
        "style_ls": style_ls,
        "train": train,
        "infer": infer,
        "image_format": image_format,
        "generation_status": "todo"
    }

    os.makedirs(os.path.join(SAVING_DIR, "images"))

    image_ls = ls_encoded_string
    SAVING_DIR = f"./gpu_{str(gpu_id)}/content/data/Datasets/{str(order_id)}"

    REQUESTS_SAVING_DIR = f"./gpu_{str(gpu_id)}/content/data/requests/{str(order_id)}"

    if os.path.exists(SAVING_DIR):
        shutil.rmtree(SAVING_DIR)
    os.makedirs(SAVING_DIR)

    if os.path.exists(REQUESTS_SAVING_DIR):
        shutil.rmtree(REQUESTS_SAVING_DIR)
    os.makedirs(REQUESTS_SAVING_DIR)

    save_content = {
        "order_id": order_id,
        "gpu_id": gpu_id,
        "style_ls": style_ls,
        "train": train,
        "infer": infer,
        "image_format": image_format,
        "generation_status": "todo"
    }

    with open(f"{REQUESTS_SAVING_DIR}/request.json", "w") as file:
        json.dump(save_content, file)

    save_files(image_ls, image_format, SAVING_DIR)

    return {"status": "images saved"},  200


@app.route("/req", methods=["POST"])
def save_req():
    content = request.json
    order_id, gpu_id = content['order_id'], content['gpu_id']
    style_ls = content['style_ls']
    train = content['train']
    infer = content["infer"]
    image_ls = content['image_ls']
    image_format = content["image_format"]
    # print(f" {order_id} {gpu_id} { train} { infer} {style_ls} {image_format} ")

    SAVING_DIR = f"./gpu_{str(gpu_id)}/content/data/Datasets/{str(order_id)}"

    REQUESTS_SAVING_DIR = f"./gpu_{str(gpu_id)}/content/data/requests/{str(order_id)}"

    if os.path.exists(SAVING_DIR):
        shutil.rmtree(SAVING_DIR)
    os.makedirs(SAVING_DIR)

    if os.path.exists(REQUESTS_SAVING_DIR):
        shutil.rmtree(REQUESTS_SAVING_DIR)
    os.makedirs(REQUESTS_SAVING_DIR)

    save_content = {
        "order_id": order_id,
        "gpu_id": gpu_id,
        "style_ls": style_ls,
        "train": train,
        "infer": infer,
        "image_format": image_format,
        "generation_status": "todo"
    }
    with open(f"{REQUESTS_SAVING_DIR}/request.json", "w") as file:
        json.dump(save_content, file)

    save_files(image_ls, image_format, SAVING_DIR)

    return {"status": "images saved"},  200





@app.route("/res", methods=["GET"])
def get_req():
    content = request.json
    order_id, gpu_id = content['order_id'], content['gpu_id']
    style_name = content['style_name']
    result_order_id_dir = f"./gpu_{str(gpu_id)}/content/data/results/{order_id}"
    result_style_dir = f"{result_order_id_dir}/{style_name}"
    # print(f"tar -czvf {result_style_dir}.zip --transform='s,^\.,,' {result_style_dir}/*")
    os.chdir(f"{result_order_id_dir}")

    os.system(f"pwd")

    print(f"zip -r  {style_name} {style_name}/")
    
    os.system(
        f"zip -r  {style_name}.zip {style_name}/")

    if os.path.isfile(f"{style_name}.zip"):
        print("Found")
        return send_from_directory(f"{result_order_id_dir}", f"{style_name}.zip", as_attachment=True), 200
    # else:
    #     return {"status": "working"},  420
    return {"status": "working"},  420


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=app_port, debug=True)
